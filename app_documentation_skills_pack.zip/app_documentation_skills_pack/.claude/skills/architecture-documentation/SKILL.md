---
name: architecture-documentation
description: Use this skill to create architecture documentation, component diagrams, data-flow diagrams, C4-style views, integration maps, and Architecture Decision Records for a software application. Trigger for architektura, diagram architektury, diagram komponentów, przepływ danych, ADR, opis integracji, C4, system design, or technical architecture handover.
---

# Architecture Documentation

Create evidence-based architecture documentation and diagrams.

## Scope

Document the system at these levels when applicable:

1. Context: users, external systems, high-level boundaries.
2. Container: frontend, backend, database, queues, workers, storage, third-party services.
3. Component: major backend/frontend modules.
4. Runtime flows: important business or integration processes.
5. Deployment: environments, infrastructure, network boundaries.

## Default output

```text
docs/odbior/architektura-systemu.md
docs/odbior/adr/0001-*.md
```

## Diagram rules

Prefer Mermaid diagrams in Markdown. Only include components found in code/config or confirmed by the user.

### Context diagram template

```mermaid
flowchart LR
  User[Użytkownik] --> App[Aplikacja]
  App --> External[System zewnętrzny]
```

### Container diagram template

```mermaid
flowchart LR
  Browser[Przeglądarka] --> Frontend[Frontend]
  Frontend --> API[Backend API]
  API --> DB[(Baza danych)]
  API --> Queue[Kolejka / worker]
```

### Sequence diagram template

```mermaid
sequenceDiagram
  actor U as Użytkownik
  participant F as Frontend
  participant A as API
  participant D as Baza danych
  U->>F: Akcja użytkownika
  F->>A: Żądanie API
  A->>D: Odczyt/zapis
  A-->>F: Odpowiedź
  F-->>U: Wynik
```

## Architecture document structure

```markdown
# Architektura systemu [NAZWA]

## 1. Cel dokumentu

## 2. Kontekst systemu

## 3. Główne komponenty
| Komponent | Odpowiedzialność | Technologia | Lokalizacja w repozytorium |

## 4. Przepływ danych

## 5. Integracje zewnętrzne
| System | Kierunek | Protokół | Dane | Tryb awarii |

## 6. Model bezpieczeństwa
- Uwierzytelnianie
- Autoryzacja
- Granice zaufania
- Sekrety

## 7. Deployment i środowiska

## 8. Decyzje architektoniczne

## 9. Ograniczenia i kompromisy

## 10. Ryzyka i rekomendacje
```

## ADR template

```markdown
# ADR-[NUMER]: [Tytuł]

## Status
Proponowana / Zaakceptowana / Wycofana / Zastąpiona

## Kontekst

## Decyzja

## Konsekwencje

## Alternatywy rozważone
```

## Verification

- Cross-check diagram components against repository structure and configuration.
- Mark guessed relationships as `WYMAGA POTWIERDZENIA:`.
- Include file paths as evidence where useful.
