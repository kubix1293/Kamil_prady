---
name: developer-onboarding
description: Use this skill to create onboarding documentation for a new developer, maintenance team, or future vendor taking over a codebase. Trigger for onboarding techniczny, developer onboarding, utrzymanie aplikacji, przejęcie kodu, new maintainer guide, repo walkthrough, or source-code handover.
---

# Developer Onboarding

Create a practical guide that lets a new technical person understand, run, test, debug, and safely modify the project.

## Output

Default file:

```text
docs/odbior/04-onboarding-techniczny.md
```

## Required structure

```markdown
# Onboarding techniczny projektu [NAZWA]

## 1. Cel dokumentu

## 2. Minimalna wiedza wymagana

## 3. Szybki start
- Klonowanie repozytorium
- Instalacja zależności
- Konfiguracja `.env`
- Uruchomienie lokalne
- Uruchomienie testów

## 4. Mapa repozytorium
| Ścieżka | Znaczenie | Kiedy zaglądać |

## 5. Główne punkty wejścia
| Obszar | Plik/katalog | Opis |

## 6. Przepływ typowej zmiany
1. Utworzenie brancha
2. Implementacja
3. Testy
4. Review
5. Merge
6. Deployment

## 7. Testowanie i debugowanie

## 8. Praca z bazą danych

## 9. Praca z API i integracjami

## 10. Deployment

## 11. Typowe pułapki
| Pułapka | Objaw | Rozwiązanie |

## 12. Definicja gotowości zmiany

## 13. Kontakt / ownership
```

## Discovery

Use these evidence sources:

- README and existing docs
- Package scripts and build files
- Docker/Compose/Kubernetes/Terraform/CI files
- Tests and fixtures
- Main application entry points
- Database schema/migrations
- API route definitions

## Quality requirements

- Provide exact commands, directories, and expected outcomes.
- Include common failure modes if visible from config or known conventions.
- Avoid long prose; make it operational.
- Mark missing access/environment details as `TODO:`.
- Include a clean-checkout verification checklist.
