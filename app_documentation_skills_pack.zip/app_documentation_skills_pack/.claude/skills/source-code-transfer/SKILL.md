---
name: source-code-transfer
description: Use this skill to prepare a source-code transfer package, repository handover checklist, README requirements, dependency/license review checklist, secrets review, release tag checklist, and evidence list for client acceptance. Trigger for przekazanie kodu źródłowego, source code transfer, repo handover, kod do klienta, przekazanie repozytorium, clean repo checklist, or delivery archive.
---

# Source Code Transfer

Prepare a formal source-code transfer package for client handover.

## Goals

The recipient must be able to:

1. Access the repository or archive.
2. Verify the delivered version.
3. Build the application.
4. Run it locally or on the target environment.
5. Understand configuration without receiving secrets in plain text.
6. Continue maintenance or pass it to another vendor.

## Default output

```text
docs/odbior/05-przekazanie-kodu-zrodlowego.md
```

## Required document structure

```markdown
# Przekazanie kodu źródłowego

## 1. Informacje podstawowe
| Pole | Wartość |
| Nazwa projektu | TODO |
| Repozytorium | TODO |
| Branch/tag/commit | TODO |
| Data przekazania | TODO |
| Wykonawca | TODO |
| Klient | TODO |

## 2. Zakres przekazania
- Kod źródłowy
- Konfiguracja przykładowa
- Migracje bazy danych
- Testy
- Skrypty build/deployment
- Dokumentacja

## 3. Stan repozytorium
- Branch główny
- Tag wydania
- Commit przekazania
- Otwarte branche/PR, jeśli istotne

## 4. Instrukcja uruchomienia z czystego checkoutu

## 5. Instrukcja budowania

## 6. Instrukcja testowania

## 7. Konfiguracja i sekrety
| Element | Sposób przekazania | Uwagi |

## 8. Zależności zewnętrzne i licencje
| Pakiet/usługa | Cel | Licencja / typ umowy | Uwagi |

## 9. Elementy nieprzekazywane w repozytorium
- Sekrety produkcyjne
- Dane osobowe
- Backupi produkcyjne, chyba że uzgodniono inaczej
- Klucze prywatne

## 10. Checklista repozytorium
| Element | Status | Dowód / lokalizacja | Uwagi |

## 11. Znane ograniczenia

## 12. Potwierdzenie przekazania
```

## Repository checklist

Check or create evidence for:

- `README.md` exists and is current.
- `.env.example` exists and contains all required variables without secrets.
- Lockfiles are included when appropriate.
- Migrations are included and ordered.
- Seed data is documented if needed.
- Build/test scripts are documented.
- Deployment files are included or deployment process is documented.
- License file exists if required.
- Third-party dependencies are listed.
- Generated/vendor artifacts are intentionally included or excluded.
- No `.env`, private keys, tokens, database dumps, or credentials are committed.

## Secret handling

Never paste actual secrets. Use:

```text
Nazwa sekretu: DATABASE_URL
Sposób przekazania: menedżer haseł / szyfrowany kanał / klient tworzy we własnym systemie
Status: TODO
```

## Version evidence

Recommend creating a release tag, e.g.:

```bash
git tag -a v1.0.0-client-handover -m "Client handover release"
git rev-parse HEAD
```

Only run commands if the user explicitly allows modifications.
