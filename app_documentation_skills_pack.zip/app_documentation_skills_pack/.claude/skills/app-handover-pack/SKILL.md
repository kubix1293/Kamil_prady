---
name: app-handover-pack
description: Use this skill when preparing a complete client handover or acceptance package for a software application, including user documentation, technical documentation, API documentation, architecture notes, deployment instructions, source-code transfer checklist, and formal acceptance protocol. Trigger for Polish or English requests mentioning odbiór aplikacji, dokumentacja użytkowa, dokumentacja techniczna, przekazanie kodu, handover, acceptance package, client delivery, or project transfer.
---

# App Handover Pack

Use this skill to produce a complete, evidence-based handover package for a client receiving a software application.

## Core rule

Do not invent facts. Derive technical claims from repository files, configuration, tests, CI/CD, migrations, deployment files, comments, existing documentation, or explicit user input. Mark missing facts as `TODO:` or `WYMAGA POTWIERDZENIA:`.

## Output language

Default to Polish unless the user asks for another language. Use formal, client-facing Polish for final documents.

## Target deliverables

Create or update this structure unless the user gives a different path:

```text
docs/odbior/
  01-dokumentacja-uzytkowa.md
  02-dokumentacja-techniczna.md
  03-dokumentacja-api.md
  04-onboarding-techniczny.md
  05-przekazanie-kodu-zrodlowego.md
  06-protokol-odbioru.md
  07-checklista-odbiorowa.md
  08-rejestr-todo-i-ryzyk.md
```

If the project already has a documentation structure, preserve it and add missing files consistently.

## Discovery process

1. Identify application type, framework, package manager, runtime, database, queues, object storage, cache, background jobs, external integrations, authentication mechanism, and deployment method.
2. Inspect these files if present:
   - `README*`, `docs/**`, `package.json`, `pnpm-lock.yaml`, `yarn.lock`, `package-lock.json`
   - `composer.json`, `requirements.txt`, `pyproject.toml`, `Pipfile`, `Gemfile`, `go.mod`, `Cargo.toml`, `pom.xml`, `build.gradle`
   - `.env.example`, `.env.sample`, `config/**`, `settings/**`
   - `Dockerfile`, `docker-compose.yml`, `compose.yaml`, `k8s/**`, `helm/**`, `terraform/**`, `.github/workflows/**`, `.gitlab-ci.yml`
   - route/controller files, OpenAPI/Swagger files, GraphQL schemas
   - migrations, seeders, schema files, ORM models
   - tests and fixtures showing expected behavior.
3. Extract only verifiable facts. For unknowns, add `TODO:`.
4. Generate the deliverables in the order listed below.

## Deliverable requirements

### 01 Dokumentacja użytkowa

Audience: end users, administrators, support staff. Avoid implementation details.

Required sections:

- Cel aplikacji
- Zakres funkcjonalny
- Role użytkowników i uprawnienia
- Logowanie, wylogowanie, reset hasła
- Opis modułów
- Procesy krok po kroku
- Komunikaty, walidacje i typowe błędy
- FAQ / rozwiązywanie problemów
- Słownik pojęć
- Kontakt / ścieżka wsparcia

For each process, use this pattern:

```markdown
### Nazwa procesu

**Cel:** ...
**Wymagana rola:** ...
**Warunki wstępne:** ...

1. Wykonaj akcję.
   - Oczekiwany rezultat: ...
2. Wykonaj kolejną akcję.
   - Oczekiwany rezultat: ...

**Możliwe błędy:** ...
```

### 02 Dokumentacja techniczna

Audience: IT, administrators, future maintainers, auditors.

Required sections:

- Opis systemu
- Architektura logiczna i fizyczna
- Technologie i wersje
- Wymagania środowiskowe
- Struktura repozytorium
- Instalacja lokalna
- Konfiguracja zmiennych środowiskowych
- Budowanie aplikacji
- Uruchamianie aplikacji
- Baza danych, migracje, seedery
- Deployment i rollback
- Backup i odtworzenie
- Logi i monitoring
- Integracje zewnętrzne
- Bezpieczeństwo
- Testy
- Znane ograniczenia
- Procedury utrzymaniowe

### 03 Dokumentacja API

Generate if the application exposes an API. If not, state that no public API was detected.

Required per endpoint:

- Method and path
- Purpose
- Authentication and required role/scope
- Path parameters
- Query parameters
- Request body
- Response body
- Error responses
- Example request
- Example response

If possible, generate or update `openapi.yaml` or `openapi.json`.

### 04 Onboarding techniczny

Audience: new developer or maintenance vendor.

Required sections:

- How to read the codebase
- Main entry points
- Local setup
- Development workflow
- Tests
- Debugging
- Deployment workflow
- Common pitfalls
- Ownership and support boundaries

### 05 Przekazanie kodu źródłowego

Required checklist:

- Repository URL or transfer method
- Branch/tag/commit handed over
- Build and run instructions verified from clean checkout
- `.env.example` complete
- Migrations and seeders included
- CI/CD documented
- License and third-party dependencies reviewed
- No secrets in repository
- Known issues listed
- Handover of accounts/access/secrets handled outside documentation

### 06 Protokół odbioru

Prepare a formal acceptance protocol with:

- Project name
- Client
- Contractor
- Date
- Environment/version delivered
- Deliverables list
- Acceptance criteria
- Exceptions/reservations
- Signatures

### 07 Checklista odbiorowa

Use a table with columns:

| Obszar | Element | Status | Dowód / lokalizacja | Uwagi |

Statuses: `TAK`, `NIE`, `N/D`, `TODO`.

### 08 Rejestr TODO i ryzyk

Every unknown or risky item found during documentation must be collected here.

Use columns:

| ID | Obszar | Ryzyko / brak | Skutek | Rekomendacja | Priorytet |

## Validation checklist

Before finishing:

- Verify installation commands against actual package manager.
- Verify build/test commands exist in project files.
- Check that environment variables documented match `.env.example` or configuration usage.
- Check that documented endpoints match route definitions or OpenAPI files.
- Check that no production secrets are copied into docs.
- Mark assumptions explicitly.
- Provide a short summary of what was generated and what still requires human confirmation.

## User-facing final response

Report:

1. Files created or updated.
2. Key gaps/TODOs.
3. Suggested next step: export to DOCX/PDF or review with client.
