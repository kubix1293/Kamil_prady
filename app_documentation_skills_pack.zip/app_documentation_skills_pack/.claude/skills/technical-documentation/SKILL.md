---
name: technical-documentation
description: Use this skill to generate or audit technical documentation for a software application from its codebase, configuration, deployment files, database migrations, tests, and existing docs. Trigger for documentation techniczna, technical docs, system architecture, installation guide, deployment guide, admin guide, maintenance docs, or operational runbook.
---

# Technical Documentation

Create accurate, maintainable technical documentation based on the repository.

## Principles

- Document behavior and operational procedures, not obvious implementation details.
- Prefer verifiable facts over assumptions.
- Use `TODO:` for missing inputs.
- Keep commands copy-pasteable.
- Include expected results for commands whenever possible.
- Do not include secrets, private keys, production passwords, tokens, or real credentials.

## Discovery checklist

Inspect relevant project files:

```text
README*, docs/**
package.json, composer.json, pyproject.toml, requirements.txt, go.mod, Cargo.toml, pom.xml, build.gradle
.env.example, .env.sample, config/**
Dockerfile, docker-compose*, k8s/**, helm/**, terraform/**
.github/workflows/**, .gitlab-ci.yml
migrations/**, prisma/**, db/**, schema/**
routes, controllers, handlers, APIs, background jobs, workers
```

## Required document structure

Use this structure unless the user specifies another one:

```markdown
# Dokumentacja techniczna aplikacji [NAZWA]

## 1. Informacje podstawowe
- Nazwa systemu
- Wersja / commit / tag
- Data dokumentacji
- Autor / wykonawca
- Środowiska

## 2. Cel i zakres systemu

## 3. Architektura systemu
- Komponenty
- Warstwy
- Przepływ danych
- Integracje
- Diagram Mermaid, jeśli możliwe

## 4. Stos technologiczny
| Obszar | Technologia | Wersja | Źródło informacji |

## 5. Wymagania środowiskowe
| Komponent | Wymaganie minimalne | Uwagi |

## 6. Struktura repozytorium
| Ścieżka | Opis |

## 7. Konfiguracja
| Zmienna | Opis | Wymagana | Przykład bezpieczny |

## 8. Instalacja lokalna

## 9. Uruchomienie lokalne

## 10. Build produkcyjny

## 11. Baza danych
- Silnik
- Migracje
- Seedery
- Backup
- Restore

## 12. Deployment
- Środowiska
- Kroki wdrożenia
- Rollback
- Smoke test po wdrożeniu

## 13. Testy
- Jednostkowe
- Integracyjne
- E2E
- Manualne

## 14. Logi, monitoring i diagnostyka

## 15. Bezpieczeństwo
- Uwierzytelnianie
- Autoryzacja
- Zarządzanie sekretami
- Dane osobowe
- Rate limiting / ochrona API

## 16. Integracje zewnętrzne
| System | Cel | Protokół | Konfiguracja | Tryb awarii |

## 17. Procedury utrzymaniowe

## 18. Znane ograniczenia i ryzyka

## 19. Załączniki
```

## Architecture diagrams

Use Mermaid when diagrams help:

```mermaid
flowchart LR
  U[Użytkownik] --> F[Frontend]
  F --> A[Backend API]
  A --> DB[(Baza danych)]
```

Only include components that are supported by evidence.

## Command format

For every command block, include:

- Working directory
- Command
- Expected result
- Troubleshooting notes if common failures are evident

Example:

```markdown
### Instalacja zależności

**Katalog:** root repozytorium

```bash
npm install
```

**Oczekiwany rezultat:** zależności zostaną pobrane do `node_modules`.
```

## Quality gate

Before finalizing:

- Check commands exist in project scripts.
- Check documented environment variables exist in config or `.env.example`.
- Check database statements match actual migrations/schema.
- Check deployment steps match Docker/CI/CD files.
- Add `WYMAGA POTWIERDZENIA:` for missing production details.
