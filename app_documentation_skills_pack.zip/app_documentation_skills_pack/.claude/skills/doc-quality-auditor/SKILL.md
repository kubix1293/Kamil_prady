---
name: doc-quality-auditor
description: Use this skill to audit generated or existing documentation against a software repository before client handover. Trigger for sprawdź dokumentację, audit docs, documentation QA, czy dokumentacja zgadza się z kodem, odbiór jakościowy, verify README, verify API docs, or client handover review.
---

# Documentation Quality Auditor

Audit documentation for accuracy, completeness, safety, and handover readiness.

## Inputs

Use all available docs and repository files. Default documentation paths:

```text
README.md
docs/**
docs/odbior/**
openapi.*
```

## Audit dimensions

### 1. Accuracy against code

Check whether documented facts match:

- package manager and commands
- framework/runtime versions
- environment variables
- API routes
- database/migrations
- deployment files
- tests
- CI/CD workflows
- integrations

### 2. Completeness for client handover

Required documents:

- User documentation
- Technical documentation
- API documentation or explicit N/D
- Developer onboarding / maintenance guide
- Source-code transfer checklist
- Acceptance protocol
- Handover checklist
- TODO/risk register

### 3. Operational usability

Check:

- clean-checkout setup is possible
- install/build/test commands are present
- expected outcomes are stated
- rollback and backup/restore are documented where relevant
- logs/monitoring/troubleshooting are documented

### 4. Security and privacy

Flag:

- real secrets in docs
- real tokens, private keys, passwords, cookies
- production personal data in examples
- unsafe instructions like committing `.env`
- missing secret-transfer procedure

### 5. Readability and client readiness

Check:

- consistent terminology
- user docs do not leak unnecessary technical details
- technical docs include enough detail for maintainers
- status/TODO markers are explicit
- procedures have expected results

## Output

Create or print an audit report:

```markdown
# Audyt dokumentacji odbiorowej

## Podsumowanie
- Ocena ogólna: GOTOWE / WARUNKOWO GOTOWE / NIEGOTOWE
- Najważniejsze braki:

## Wyniki szczegółowe
| Obszar | Ocena | Dowód | Problem | Rekomendacja |

## Krytyczne blokery odbioru

## Braki do uzupełnienia przed przekazaniem

## Sugestie ulepszeń

## Lista znalezionych TODO

## Ryzyka bezpieczeństwa

## Decyzja rekomendowana
```

## Severity scale

- `KRYTYCZNE`: blocks handover or exposes secrets/security risk.
- `WYSOKIE`: likely to block client from running/maintaining app.
- `ŚREDNIE`: documentation incomplete but manageable.
- `NISKIE`: polish/readability improvement.

## Rules

- Include evidence paths where possible.
- Do not modify files unless asked.
- If you find secrets, do not repeat their full values. Show only variable/file location and a redacted preview.
