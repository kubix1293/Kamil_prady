---
name: api-documentation
description: Use this skill to generate, update, or audit API documentation from route definitions, controllers, handlers, OpenAPI/Swagger specs, GraphQL schemas, tests, or API clients. Trigger for API docs, dokumentacja API, Swagger, OpenAPI, endpointy, REST, GraphQL, integracje, request/response examples, or external integration handover.
---

# API Documentation

Generate accurate API documentation from code and existing specs.

## Discovery

Look for:

```text
openapi.yaml, openapi.yml, openapi.json, swagger.json, swagger.yaml
routes/**, controllers/**, handlers/**, api/**, pages/api/**, app/api/**
graphql/**, schema.graphql, *.graphql
postman collections, Bruno collections, Insomnia exports
tests exercising HTTP endpoints
API client code in frontend/mobile packages
```

## Output files

Default output:

```text
docs/odbior/03-dokumentacja-api.md
docs/odbior/openapi.yaml   # if enough information is available
```

## REST endpoint template

Use this template for every endpoint:

```markdown
### `METHOD /path`

**Opis:** ...
**Autoryzacja:** ...
**Wymagana rola/scope:** ...
**Content-Type:** `application/json`

#### Parametry ścieżki
| Nazwa | Typ | Wymagany | Opis |

#### Parametry query
| Nazwa | Typ | Wymagany | Domyślnie | Opis |

#### Request body
```json
{}
```

#### Response 200/201
```json
{}
```

#### Błędy
| Kod HTTP | Kod aplikacyjny | Znaczenie | Zalecana reakcja |

#### Przykład
```bash
curl -X GET "https://api.example.com/path" \
  -H "Authorization: Bearer <token>"
```
```

## OpenAPI rules

If generating OpenAPI:

- Use OpenAPI 3.0 or 3.1.
- Include `info`, `servers`, `paths`, `components.schemas`, and `components.securitySchemes` when known.
- Use placeholder server URL if production/staging URLs are unknown.
- Never include real tokens, passwords, cookies, or personal data.
- Prefer examples from tests or fixtures; otherwise use synthetic safe examples.

## GraphQL rules

For GraphQL APIs, document:

- Endpoint URL
- Authentication
- Queries
- Mutations
- Subscriptions, if present
- Input types
- Return types
- Error model
- Example operation and variables

## Accuracy requirements

- Do not document endpoints that are not present in code/spec/tests unless explicitly requested as planned APIs.
- Mark undocumented auth behavior as `TODO: potwierdzić mechanizm autoryzacji`.
- Compare frontend API client calls against backend route definitions and report mismatches.
- Include versioning and deprecation notes if found.
