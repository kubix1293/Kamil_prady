---
name: handover-checklist
description: Use this skill to create a formal software acceptance protocol, client handover checklist, delivery register, sign-off document, or odbiór/protokół przekazania for an application project. Trigger for protokół odbioru, checklista odbiorowa, przekazanie aplikacji, sign-off, acceptance protocol, handover checklist, or formal client delivery.
---

# Handover Checklist

Create formal acceptance and handover documents for software delivery.

## Default outputs

```text
docs/odbior/06-protokol-odbioru.md
docs/odbior/07-checklista-odbiorowa.md
```

## Acceptance protocol template

```markdown
# Protokół przekazania i odbioru aplikacji

## 1. Informacje podstawowe
| Pole | Wartość |
| Nazwa projektu | TODO |
| Zamawiający / Klient | TODO |
| Wykonawca | TODO |
| Data przekazania | TODO |
| Miejsce / forma przekazania | TODO |
| Wersja aplikacji | TODO |
| Commit/tag | TODO |
| Środowisko | TODO |

## 2. Przedmiot przekazania
Wykonawca przekazuje Zamawiającemu aplikację [NAZWA] wraz z dokumentacją i elementami wymienionymi w niniejszym protokole.

## 3. Zakres przekazanych elementów
| Lp. | Element | Status | Lokalizacja / forma przekazania | Uwagi |
| 1 | Aplikacja / wdrożenie | TODO | TODO | TODO |
| 2 | Kod źródłowy | TODO | TODO | TODO |
| 3 | Dokumentacja użytkowa | TODO | TODO | TODO |
| 4 | Dokumentacja techniczna | TODO | TODO | TODO |
| 5 | Dokumentacja API | TODO | TODO | TODO |
| 6 | Instrukcja deploymentu | TODO | TODO | TODO |
| 7 | Konfiguracja przykładowa | TODO | TODO | TODO |
| 8 | Migracje bazy danych | TODO | TODO | TODO |
| 9 | Dostępy administracyjne | TODO | TODO | TODO |
| 10 | Sposób przekazania sekretów | TODO | TODO | TODO |

## 4. Kryteria odbioru
| Kryterium | Status | Dowód | Uwagi |

## 5. Uwagi i zastrzeżenia

## 6. Elementy wymagające dalszych działań
| Element | Odpowiedzialny | Termin | Uwagi |

## 7. Oświadczenia stron
Wykonawca oświadcza, że przekazane elementy są zgodne ze stanem projektu na dzień przekazania, z zastrzeżeniami wskazanymi w protokole.

Zamawiający potwierdza odbiór elementów wymienionych w protokole.

## 8. Podpisy
| Strona | Imię i nazwisko | Podpis | Data |
| Wykonawca |  |  |  |
| Zamawiający |  |  |  |
```

## Checklist template

```markdown
# Checklista odbiorowa

| Obszar | Element | Status | Dowód / lokalizacja | Uwagi |
|---|---|---:|---|---|
| Aplikacja | Aplikacja działa na ustalonym środowisku | TODO | TODO | TODO |
| Kod | Repozytorium przekazane klientowi | TODO | TODO | TODO |
| Kod | Wskazany branch/tag/commit odbiorowy | TODO | TODO | TODO |
| Kod | Brak sekretów w repozytorium | TODO | TODO | TODO |
| Konfiguracja | `.env.example` kompletny | TODO | TODO | TODO |
| Baza danych | Migracje kompletne | TODO | TODO | TODO |
| Baza danych | Backup/restore opisany | TODO | TODO | TODO |
| Dokumentacja | Dokumentacja użytkowa gotowa | TODO | TODO | TODO |
| Dokumentacja | Dokumentacja techniczna gotowa | TODO | TODO | TODO |
| Dokumentacja | Dokumentacja API gotowa albo oznaczona jako N/D | TODO | TODO | TODO |
| Deployment | Deployment opisany | TODO | TODO | TODO |
| Deployment | Rollback opisany | TODO | TODO | TODO |
| Testy | Testy opisane i możliwe do uruchomienia | TODO | TODO | TODO |
| Bezpieczeństwo | Role/uprawnienia opisane | TODO | TODO | TODO |
| Utrzymanie | Logi i monitoring opisane | TODO | TODO | TODO |
| Utrzymanie | Znane ograniczenia opisane | TODO | TODO | TODO |
```

## Status values

Use exactly:

- `TAK` — complete and verified.
- `NIE` — not complete.
- `N/D` — not applicable.
- `TODO` — requires confirmation.

## Finalization rules

- Keep protocol formal and neutral.
- Do not imply legal acceptance beyond the user's instructions.
- Include reservations explicitly rather than hiding them.
- Keep access credentials and secrets out of the protocol.
