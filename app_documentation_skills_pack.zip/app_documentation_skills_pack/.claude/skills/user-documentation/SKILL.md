---
name: user-documentation
description: Use this skill to create end-user documentation, user manuals, administrator manuals, process instructions, FAQ, and troubleshooting guides for a software application. Trigger for dokumentacja użytkowa, instrukcja użytkownika, podręcznik użytkownika, manual, administrator guide, role-based usage guide, or klient ma dostać instrukcję obsługi.
---

# User Documentation

Create clear, task-oriented documentation for people using the application.

## Audience

Default audiences:

- End user: performs daily business tasks.
- Administrator: manages users, roles, dictionaries, settings, and operational configuration.
- Support: helps users diagnose common problems.

Ask only when audience cannot be inferred. Otherwise generate role-based sections and mark uncertain parts as `TODO:`.

## Style rules

- Use Polish by default.
- Use direct, practical language.
- Avoid implementation details, code names, framework names, database terms, and internal architecture unless the reader needs them.
- Each procedure must say what the user should see after each step.
- Define application-specific terms on first use.
- Use screenshots placeholders if screenshots are not available.

## Required structure

```markdown
# Dokumentacja użytkowa aplikacji [NAZWA]

## 1. Informacje o dokumencie
- Wersja dokumentu
- Data
- Wersja aplikacji
- Odbiorcy dokumentu

## 2. Cel aplikacji

## 3. Zakres funkcjonalny

## 4. Role i uprawnienia
| Rola | Opis | Dostępne funkcje |

## 5. Pierwsze kroki
- Dostęp do aplikacji
- Logowanie
- Wylogowanie
- Reset hasła
- Zmiana hasła, jeśli występuje

## 6. Nawigacja po aplikacji
- Menu
- Widoki
- Filtry
- Wyszukiwarka
- Akcje masowe, jeśli występują

## 7. Procesy użytkownika

## 8. Procesy administratora

## 9. Powiadomienia i komunikaty
| Komunikat | Znaczenie | Zalecane działanie |

## 10. Typowe problemy i rozwiązania
| Problem | Możliwa przyczyna | Rozwiązanie |

## 11. Słownik pojęć

## 12. Kontakt i wsparcie
```

## Procedure pattern

Use this for every business process:

```markdown
### [Nazwa procesu]

**Dla kogo:** [rola]
**Cel:** [po co użytkownik wykonuje proces]
**Warunki wstępne:** [co musi być spełnione]

1. Kliknij [element interfejsu].
   - Oczekiwany rezultat: [co pojawia się na ekranie].
2. Wypełnij pole [nazwa pola].
   - Oczekiwany rezultat: system zaakceptuje wartość albo pokaże walidację.
3. Kliknij **Zapisz**.
   - Oczekiwany rezultat: [komunikat/status].

**Możliwe błędy:**
- [komunikat]: [co oznacza i co zrobić].

**Uwagi:**
- [ograniczenia lub wyjątki].
```

## Deriving content

Use available sources in this order:

1. User stories, requirements, tickets, acceptance criteria, existing docs.
2. UI code, route names, labels, translations, form validation messages.
3. Tests/E2E flows.
4. API/domain names only as supporting evidence.

If the UI is not available, produce a draft with `TODO: potwierdzić nazwę przycisku/widoku`.

## Accessibility and clarity

- Avoid phrases like “oczywiście”, “po prostu”, “łatwo”.
- Use consistent names for buttons, fields, modules, and roles.
- Explain consequences of destructive actions before the steps.
- Include “how to verify success” for each workflow.
