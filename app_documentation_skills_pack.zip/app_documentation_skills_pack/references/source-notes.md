# Source notes

This pack is a custom, Polish-language adaptation for client handover documentation. It is not a verbatim mirror of upstream agents or commands.

Useful upstream references checked while preparing the pack:

- Anthropic Skills repository: skill folders with `SKILL.md` and optional resources.
- Claude Code skills documentation: skills can live in `.claude/skills` and be invoked with `/skill-name`.
- Claude Help Center: custom Claude.ai skills are uploaded as ZIP files containing a single skill folder.
- Awesome Claude Code Toolkit: documentation-related agents and commands such as documentation engineer, technical writer, doc generation, and API docs.
