# Protokół przekazania i odbioru aplikacji

## 1. Informacje podstawowe
| Pole | Wartość |
|---|---|
| Nazwa projektu | TODO |
| Zamawiający / Klient | TODO |
| Wykonawca | TODO |
| Data przekazania | TODO |
| Wersja aplikacji | TODO |
| Commit/tag | TODO |
| Środowisko | TODO |

## 2. Przedmiot przekazania
Wykonawca przekazuje Zamawiającemu aplikację [NAZWA] wraz z dokumentacją i elementami wymienionymi w niniejszym protokole.

## 3. Zakres przekazanych elementów
| Lp. | Element | Status | Lokalizacja / forma przekazania | Uwagi |
|---:|---|---|---|---|
| 1 | Aplikacja / wdrożenie | TODO | TODO | TODO |
| 2 | Kod źródłowy | TODO | TODO | TODO |
| 3 | Dokumentacja użytkowa | TODO | TODO | TODO |
| 4 | Dokumentacja techniczna | TODO | TODO | TODO |
| 5 | Dokumentacja API | TODO | TODO | TODO |
| 6 | Instrukcja deploymentu | TODO | TODO | TODO |
| 7 | Konfiguracja przykładowa | TODO | TODO | TODO |
| 8 | Migracje bazy danych | TODO | TODO | TODO |
| 9 | Dostępy administracyjne | TODO | TODO | TODO |
| 10 | Sposób przekazania sekretów | TODO | TODO | TODO |

## 4. Kryteria odbioru
| Kryterium | Status | Dowód | Uwagi |
|---|---|---|---|
| TODO | TODO | TODO | TODO |

## 5. Uwagi i zastrzeżenia
TODO

## 6. Elementy wymagające dalszych działań
| Element | Odpowiedzialny | Termin | Uwagi |
|---|---|---|---|
| TODO | TODO | TODO | TODO |

## 7. Oświadczenia stron
Wykonawca oświadcza, że przekazane elementy są zgodne ze stanem projektu na dzień przekazania, z zastrzeżeniami wskazanymi w protokole.

Zamawiający potwierdza odbiór elementów wymienionych w protokole.

## 8. Podpisy
| Strona | Imię i nazwisko | Podpis | Data |
|---|---|---|---|
| Wykonawca |  |  |  |
| Zamawiający |  |  |  |
