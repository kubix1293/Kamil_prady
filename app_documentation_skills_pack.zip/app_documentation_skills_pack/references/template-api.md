# Dokumentacja API aplikacji [NAZWA]

## 1. Informacje podstawowe
| Pole | Wartość |
|---|---|
| Bazowy adres API | TODO |
| Wersja API | TODO |
| Format danych | JSON |
| Autoryzacja | TODO |

## 2. Autoryzacja
TODO

## 3. Endpointy

### `METHOD /path`

**Opis:** TODO  
**Autoryzacja:** TODO  
**Wymagana rola/scope:** TODO

#### Parametry ścieżki
| Nazwa | Typ | Wymagany | Opis |
|---|---|---|---|
| TODO | TODO | TODO | TODO |

#### Parametry query
| Nazwa | Typ | Wymagany | Domyślnie | Opis |
|---|---|---|---|---|
| TODO | TODO | TODO | TODO | TODO |

#### Request body
```json
{}
```

#### Response
```json
{}
```

#### Błędy
| Kod HTTP | Znaczenie | Zalecana reakcja |
|---|---|---|
| TODO | TODO | TODO |

#### Przykład
```bash
curl -X GET "https://api.example.com/path" \
  -H "Authorization: Bearer <token>"
```
