# Dokumentacja użytkowa aplikacji [NAZWA]

## 1. Informacje o dokumencie
| Pole | Wartość |
|---|---|
| Wersja dokumentu | TODO |
| Data | TODO |
| Wersja aplikacji | TODO |
| Odbiorcy | Użytkownicy końcowi, administratorzy, wsparcie |

## 2. Cel aplikacji
TODO

## 3. Zakres funkcjonalny
TODO

## 4. Role i uprawnienia
| Rola | Opis | Dostępne funkcje |
|---|---|---|
| TODO | TODO | TODO |

## 5. Pierwsze kroki
### Logowanie
1. Otwórz adres aplikacji: TODO.
   - Oczekiwany rezultat: wyświetli się ekran logowania.
2. Wpisz login i hasło.
   - Oczekiwany rezultat: pola formularza zostaną uzupełnione.
3. Kliknij **Zaloguj**.
   - Oczekiwany rezultat: aplikacja wyświetli ekran startowy.

### Wylogowanie
TODO

### Reset hasła
TODO

## 6. Nawigacja po aplikacji
TODO

## 7. Procesy użytkownika
### [Nazwa procesu]
**Dla kogo:** TODO  
**Cel:** TODO  
**Warunki wstępne:** TODO

1. TODO
   - Oczekiwany rezultat: TODO

**Możliwe błędy:** TODO

## 8. Procesy administratora
TODO

## 9. Komunikaty i walidacje
| Komunikat | Znaczenie | Zalecane działanie |
|---|---|---|
| TODO | TODO | TODO |

## 10. Typowe problemy i rozwiązania
| Problem | Możliwa przyczyna | Rozwiązanie |
|---|---|---|
| TODO | TODO | TODO |

## 11. Słownik pojęć
| Pojęcie | Znaczenie |
|---|---|
| TODO | TODO |

## 12. Kontakt i wsparcie
TODO
