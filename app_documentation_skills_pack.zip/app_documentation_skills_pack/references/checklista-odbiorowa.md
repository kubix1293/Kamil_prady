# Checklista odbiorowa

| Obszar | Element | Status | Dowód / lokalizacja | Uwagi |
|---|---|---:|---|---|
| Aplikacja | Aplikacja działa na ustalonym środowisku | TODO | TODO | TODO |
| Kod | Repozytorium przekazane klientowi | TODO | TODO | TODO |
| Kod | Wskazany branch/tag/commit odbiorowy | TODO | TODO | TODO |
| Kod | Brak sekretów w repozytorium | TODO | TODO | TODO |
| Konfiguracja | `.env.example` kompletny | TODO | TODO | TODO |
| Baza danych | Migracje kompletne | TODO | TODO | TODO |
| Baza danych | Backup/restore opisany | TODO | TODO | TODO |
| Dokumentacja | Dokumentacja użytkowa gotowa | TODO | TODO | TODO |
| Dokumentacja | Dokumentacja techniczna gotowa | TODO | TODO | TODO |
| Dokumentacja | Dokumentacja API gotowa albo oznaczona jako N/D | TODO | TODO | TODO |
| Deployment | Deployment opisany | TODO | TODO | TODO |
| Deployment | Rollback opisany | TODO | TODO | TODO |
| Testy | Testy opisane i możliwe do uruchomienia | TODO | TODO | TODO |
| Bezpieczeństwo | Role/uprawnienia opisane | TODO | TODO | TODO |
| Utrzymanie | Logi i monitoring opisane | TODO | TODO | TODO |
| Utrzymanie | Znane ograniczenia opisane | TODO | TODO | TODO |
