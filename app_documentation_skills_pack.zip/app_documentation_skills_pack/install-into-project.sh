#!/usr/bin/env bash
set -euo pipefail

TARGET="${1:-.}"
mkdir -p "$TARGET/.claude/skills"
cp -R .claude/skills/* "$TARGET/.claude/skills/"
echo "Installed skills into $TARGET/.claude/skills"
