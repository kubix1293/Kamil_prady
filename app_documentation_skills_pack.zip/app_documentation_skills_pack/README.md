# App Documentation Skills Pack

Pakiet skillów do przygotowania odbioru aplikacji u klienta: dokumentacja użytkowa, dokumentacja techniczna, dokumentacja API, onboarding dla utrzymania, lista kontrolna przekazania kodu źródłowego i protokół odbioru.

## Zawartość

```text
.claude/skills/
  app-handover-pack/
  technical-documentation/
  user-documentation/
  api-documentation/
  architecture-documentation/
  developer-onboarding/
  source-code-transfer/
  handover-checklist/
  doc-quality-auditor/
individual-zips/
  <osobne ZIP-y dla Claude.ai>
references/
  szablony dokumentów i checklisty
```

## Instalacja w Claude Code

Skopiuj folder `.claude/skills` do katalogu głównego projektu albo połącz go z istniejącym folderem `.claude/skills`:

```bash
cp -R .claude/skills ./twoj-projekt/.claude/
```

Potem w Claude Code możesz używać slash commands, np.:

```text
/app-handover-pack przygotuj pełny pakiet odbiorowy dla tej aplikacji
/technical-documentation wygeneruj dokumentację techniczną z repozytorium
/user-documentation przygotuj instrukcję użytkownika dla klienta
/api-documentation opisz API i przygotuj OpenAPI, jeśli możliwe
/doc-quality-auditor sprawdź czy dokumentacja zgadza się z kodem
```

## Instalacja w Claude.ai

W folderze `individual-zips/` są osobne ZIP-y. W Claude.ai zwykle należy wgrać każdy skill osobno w `Customize > Skills > Create skill > Upload a skill`.

## Rekomendowany workflow odbiorowy

1. Uruchom `/app-handover-pack` w katalogu projektu.
2. Uruchom `/api-documentation`, jeśli aplikacja ma API.
3. Uruchom `/architecture-documentation`, jeśli potrzebujesz diagramów.
4. Uruchom `/doc-quality-auditor`, żeby sprawdzić spójność dokumentacji z kodem.
5. Uzupełnij ręcznie pola oznaczone `TODO:` — szczególnie dane klienta, dane dostępowe, środowiska i decyzje biznesowe.
6. Wyeksportuj finalne dokumenty do DOCX/PDF według wymagań klienta.

## Zasady bezpieczeństwa

- Nie wpisuj sekretów produkcyjnych do dokumentacji ani do repozytorium.
- W dokumentacji używaj nazw zmiennych i procedury bezpiecznego przekazania sekretów, np. menedżer haseł lub szyfrowany kanał.
- Każde twierdzenie techniczne powinno wynikać z kodu, konfiguracji, testów, CI/CD, migracji albo jawnych informacji od właściciela projektu.
- Elementy niepewne oznaczaj jako `TODO:` albo `WYMAGA POTWIERDZENIA:`.

## Źródła inspiracji

Pakiet jest autorską adaptacją wzorców z ekosystemu Claude Skills i Claude Code, przygotowaną pod formalne przekazanie aplikacji klientowi. Nie jest kopią 1:1 upstreamowych agentów/komend.
