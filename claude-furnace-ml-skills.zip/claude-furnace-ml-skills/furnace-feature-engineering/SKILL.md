---
name: furnace-feature-engineering
description: Use when creating ML features from furnace time series for dew point, energy consumption, anomaly detection or furnace health models.
---

# Feature engineering dla pieców przemysłowych

## Cel
Zbuduj cechy czasowe i procesowe dla modeli predykcji punktu rosy, zużycia energii i kondycji pieca.

## Procedura
1. Ustal częstotliwość danych, np. 1 minuta.
2. Posortuj po furnace_id i timestamp.
3. Dodaj lagi: 1, 5, 15, 30, 60 minut.
4. Dodaj rolling mean/std/min/max dla okien 5, 15, 30, 60 minut.
5. Dodaj cechy różnicowe: actual minus setpoint, gradient temperatury, zmiana przepływu, zmiana punktu rosy.
6. Dodaj cechy produkcyjne: energia na kg, gaz na kg, obciążenie, recipe_id, line_speed.
7. Dodaj flagi stanu: door_open, alarm, startup, shutdown, idle, recipe_change.
8. Nie używaj leakage: cechy z przyszłości i wyników jakości znanych dopiero po procesie nie mogą wejść do predykcji online.

## Wynik
Dataset treningowy z listą cech, targetem i opisem ryzyka leakage.

