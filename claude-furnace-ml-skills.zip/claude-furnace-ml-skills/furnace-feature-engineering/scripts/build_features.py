import sys
import pandas as pd

path = sys.argv[1]
df = pd.read_csv(path, parse_dates=['timestamp'])
df = df.sort_values(['furnace_id','timestamp'] if 'furnace_id' in df.columns else ['timestamp'])

group_cols = ['furnace_id'] if 'furnace_id' in df.columns else None
numeric_cols = [c for c in df.select_dtypes('number').columns if c not in ['quality_result']]

for col in numeric_cols:
    base = df.groupby(group_cols)[col] if group_cols else df[col]
    for lag in [1,5,15,30,60]:
        df[f'{col}_lag_{lag}'] = base.shift(lag) if group_cols else df[col].shift(lag)
    for win in [5,15,30,60]:
        if group_cols:
            df[f'{col}_roll_mean_{win}'] = df.groupby(group_cols)[col].transform(lambda s: s.rolling(win, min_periods=3).mean())
            df[f'{col}_roll_std_{win}'] = df.groupby(group_cols)[col].transform(lambda s: s.rolling(win, min_periods=3).std())
        else:
            df[f'{col}_roll_mean_{win}'] = df[col].rolling(win, min_periods=3).mean()
            df[f'{col}_roll_std_{win}'] = df[col].rolling(win, min_periods=3).std()

if {'energy_kwh','load_mass_kg'}.issubset(df.columns):
    df['energy_kwh_per_kg'] = df['energy_kwh'] / df['load_mass_kg'].replace(0, pd.NA)

out = 'features_dataset.parquet'
df.to_parquet(out, index=False)
print(f'Zapisano: {out}, rows={len(df)}, cols={len(df.columns)}')
