---
name: furnace-maintenance-reporting
description: Use when generating a maintenance or process engineering report from furnace ML predictions, anomalies, health diagnostics and production data.
---

# Raport UR i technologiczny

## Cel
Twórz raporty dla utrzymania ruchu, technologów i kierownika produkcji.

## Struktura raportu
1. Podsumowanie wykonawcze.
2. Status pieca: GREEN / YELLOW / RED.
3. Punkt rosy: trend, predykcja, przekroczenia, przyczyny.
4. Energia: zużycie rzeczywiste vs oczekiwane, energia na jednostkę produkcji.
5. Anomalie: czas, severity, objaw, potencjalna przyczyna.
6. Kondycja: health score i trend.
7. Rekomendacje: natychmiast / w tym tygodniu / przy najbliższym postoju.
8. Załącznik techniczny: metryki modeli i jakość danych.

## Styl
Pisz konkretnie, językiem zakładu: objaw → możliwa przyczyna → akcja → priorytet.
Unikaj ogólników.

