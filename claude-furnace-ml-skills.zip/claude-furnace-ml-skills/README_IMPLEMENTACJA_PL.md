# Claude Skills dla predykcji punktu rosy, energii i kondycji pieca

Ten pakiet zawiera 7 gotowych custom Claude Skills do użycia jako wzorzec wdrożenia w zakładzie produkcyjnym.

## Co jest w pakiecie

1. `furnace-data-quality` — kontrola jakości danych z PLC/SCADA/MES/historian.
2. `furnace-feature-engineering` — tworzenie cech czasowych dla modeli ML.
3. `dew-point-prediction` — predykcja punktu rosy.
4. `furnace-energy-forecast` — predykcja zużycia energii pieca.
5. `furnace-anomaly-detection` — wykrywanie anomalii procesu.
6. `furnace-health-diagnostics` — ocena kondycji pieca na podstawie reszt modeli i sygnałów procesowych.
7. `furnace-maintenance-reporting` — raport dla UR/technologa z rekomendacjami.

## Jak wrzucić do Claude.ai

Dla Claude.ai zwykle pakujesz pojedynczy skill jako ZIP:

```
furnace-data-quality.zip
└── furnace-data-quality/
    ├── SKILL.md
    └── scripts/
```

Nie pakuj samych plików bez folderu głównego. Nazwa folderu powinna odpowiadać nazwie skilla.

## Jak używać w Claude Code

Skopiuj foldery do:

```
.claude/skills/
```

Przykład:

```
.claude/skills/dew-point-prediction/SKILL.md
.claude/skills/dew-point-prediction/scripts/train_dew_point_model.py
```

## Minimalny workflow wdrożenia

1. Eksportuj dane historyczne z SCADA/historian/MES do CSV/Parquet.
2. Ujednolić timestamp, strefę czasową i częstotliwość próbkowania, np. 1 minuta.
3. Uruchomić `furnace-data-quality`.
4. Uruchomić `furnace-feature-engineering`.
5. Wytrenować osobno:
   - model punktu rosy,
   - model zużycia energii,
   - model anomalii.
6. Porównywać wartości rzeczywiste z predykcją.
7. Używać `furnace-health-diagnostics` do interpretacji: nieszczelność, degradacja izolacji, problem z palnikiem/grzałką, niestabilny gaz ochronny, błąd czujnika.
8. Generować raporty przez `furnace-maintenance-reporting`.

## Zalecany stos techniczny

- Python 3.10+
- pandas, numpy
- scikit-learn
- lightgbm lub xgboost
- matplotlib / plotly do wykresów
- MLflow do rejestracji modeli
- Airflow/Prefect/cron do harmonogramu
- Grafana/Power BI do dashboardów

## Minimalny schemat danych wejściowych

Wystarczą kolumny typu:

```
timestamp
furnace_id
recipe_id
zone_1_temp, zone_2_temp, zone_3_temp
zone_1_setpoint, zone_2_setpoint, zone_3_setpoint
dew_point
oxygen_ppm
hydrogen_pct
nitrogen_flow
gas_flow
line_speed
load_mass_kg
energy_kwh
gas_nm3
door_open_flag
alarm_code
quality_result
maintenance_event
```

## Ważna uwaga

Claude Skill nie jest samym modelem ML. Skill jest playbookiem i narzędziem roboczym, które mówi Claude, jak analizować dane, jakie skrypty uruchomić i jak interpretować wyniki. Model ML powinien być trenowany, wersjonowany i walidowany osobno.
