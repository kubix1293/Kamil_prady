---
name: furnace-anomaly-detection
description: Use when detecting abnormal furnace behavior, sensor drift, process instability, leaks, energy anomalies or dew point excursions.
---

# Detekcja anomalii pieca

## Cel
Wykrywaj zachowania odbiegające od normalnej pracy pieca.

## Podejścia
1. Reguły SPC dla krytycznych zmiennych.
2. IsolationForest lub OneClassSVM dla cech numerycznych.
3. Analiza residuali: actual minus predicted dla punktu rosy i energii.
4. Wykrywanie dryfu czujników i zamrożonych sygnałów.

## Zasady
- Nie traktuj każdej anomalii jako awarii. Oznacz kontekst: zmiana receptury, otwarcie drzwi, start/stop, postój.
- Priorytetuj anomalie powtarzalne lub narastające.
- Podaj severity: LOW / MEDIUM / HIGH / CRITICAL.

