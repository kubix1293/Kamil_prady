import sys, joblib
import pandas as pd
from sklearn.ensemble import IsolationForest

path = sys.argv[1]
df = pd.read_parquet(path) if path.endswith('.parquet') else pd.read_csv(path)
X = df.select_dtypes('number').fillna(0)
model = IsolationForest(n_estimators=300, contamination=0.02, random_state=42)
model.fit(X)
df['anomaly_score'] = model.decision_function(X)
df['is_anomaly'] = model.predict(X) == -1
df.to_csv('anomaly_scored.csv', index=False)
joblib.dump({'model': model, 'features': list(X.columns)}, 'anomaly_model.joblib')
print(df['is_anomaly'].value_counts().to_dict())
