import sys
import pandas as pd

path = sys.argv[1]
df = pd.read_csv(path)
score = 100
findings = []

def penalize(condition, points, finding):
    global score
    if condition:
        score -= points
        findings.append(finding)

if 'dew_point_residual' in df.columns:
    penalize(df['dew_point_residual'].tail(120).mean() > 3, 20, 'Punkt rosy stale powyżej modelu: sprawdzić nieszczelności, gaz ochronny, czujnik.')
if 'energy_residual' in df.columns:
    penalize(df['energy_residual'].tail(120).mean() > 0, 20, 'Energia powyżej modelu: sprawdzić izolację, palniki/grzałki, drzwi.')
if 'is_anomaly' in df.columns:
    penalize(df['is_anomaly'].tail(120).mean() > 0.10, 15, 'Wysoki udział anomalii w ostatnim oknie pracy.')
if 'oxygen_ppm' in df.columns and 'dew_point' in df.columns:
    penalize((df['oxygen_ppm'].tail(120).mean() > df['oxygen_ppm'].median()*1.5) and (df['dew_point'].tail(120).mean() > df['dew_point'].median()), 15, 'Jednoczesny wzrost O2 i punktu rosy: podejrzenie dopływu powietrza.')

score = max(0, min(100, score))
print({'health_score': score, 'findings': findings})
