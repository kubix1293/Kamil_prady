---
name: furnace-health-diagnostics
description: Use when assessing furnace health, degradation, leaks, insulation loss, burner/heater issues or maintenance needs from ML predictions and process data.
---

# Diagnostyka kondycji pieca

## Cel
Ocenić kondycję pieca na podstawie sygnałów procesowych, predykcji ML, residuali i historii maintenance.

## Wejścia
- Predykcja punktu rosy i actual dew_point.
- Predykcja energii i actual energy/gas.
- Anomalie procesu.
- Alarmy, otwarcia drzwi, receptura, wsad.
- Maintenance_event i jakość produktu.

## Logika diagnostyczna
- Wysoki residual punktu rosy + wzrost O2 + brak zmiany receptury: podejrzenie nieszczelności lub problemu z atmosferą.
- Wysoki residual energii + stabilna masa/wsad + stabilne setpointy: możliwa degradacja izolacji, rozregulowanie palników/grzałek lub straty przez drzwi.
- Niestabilna temperatura strefy + wysoka moc sterowania: problem z regulacją, palnikiem, grzałką lub czujnikiem temperatury.
- Skok punktu rosy po otwarciu drzwi: sprawdzić procedurę załadunku, kurtyny i przepływ gazu ochronnego.
- Powolny trend pogorszenia przez tygodnie: planować przegląd, nie tylko reakcję alarmową.

## Wynik
Health score 0-100, lista symptomów, prawdopodobne przyczyny, rekomendowane akcje, pilność i pewność diagnozy.

