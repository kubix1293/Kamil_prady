---
name: furnace-data-quality
description: Use when validating SCADA, PLC, MES, historian, furnace sensor, dew point or energy data before machine learning.
---

# Kontrola jakości danych pieca

## Cel
Sprawdź, czy dane z linii produkcyjnej nadają się do modelowania ML dla punktu rosy, energii i kondycji pieca.

## Procedura
1. Sprawdź kolumnę timestamp: duplikaty, przerwy, skoki czasu, strefa czasowa.
2. Sprawdź brakujące dane dla krytycznych sygnałów: dew_point, energy_kwh, gas_flow, zone temperatures, setpoints, flows, oxygen.
3. Wykryj czujniki zamrożone: brak zmienności przez długi czas.
4. Wykryj wartości fizycznie niemożliwe lub podejrzane.
5. Oddziel awarie czujnika od realnych anomalii procesu.
6. Zwróć tabelę problemów: kolumna, typ problemu, zakres czasu, wpływ na model, rekomendacja.

## Reguły domenowe
- Nie usuwaj automatycznie anomalii procesowych; oznacz je flagą.
- Otwieranie drzwi, zmiana receptury i postój to osobne stany procesu.
- Dane jakościowe i maintenance_event traktuj jako etykiety pomocnicze, nie jako zwykłe cechy czasu rzeczywistego, jeśli nie są dostępne online.

## Wynik
Raport jakości danych oraz rekomendacja: GO / GO_WITH_WARNINGS / NO_GO dla trenowania modelu.

