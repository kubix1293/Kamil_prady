import sys
import pandas as pd

path = sys.argv[1]
df = pd.read_csv(path)
issues = []

if 'timestamp' not in df.columns:
    issues.append(('timestamp', 'missing_column', 'Brak kolumny timestamp'))
else:
    ts = pd.to_datetime(df['timestamp'], errors='coerce')
    if ts.isna().mean() > 0:
        issues.append(('timestamp', 'parse_error', f"Nieparsowalne timestampy: {ts.isna().mean():.2%}"))
    if ts.duplicated().any():
        issues.append(('timestamp', 'duplicates', f"Duplikaty timestamp: {int(ts.duplicated().sum())}"))

for col in df.columns:
    miss = df[col].isna().mean()
    if miss > 0.05:
        issues.append((col, 'missing_values', f"Braki danych: {miss:.2%}"))
    if pd.api.types.is_numeric_dtype(df[col]):
        if df[col].nunique(dropna=True) <= 1:
            issues.append((col, 'constant_signal', 'Sygnał stały lub zamrożony'))

out = pd.DataFrame(issues, columns=['column','issue_type','details'])
out.to_csv('data_quality_report.csv', index=False)
print(out.to_string(index=False) if not out.empty else 'GO: brak istotnych problemów jakości danych')
