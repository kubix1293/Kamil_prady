---
name: furnace-energy-forecast
description: Use when forecasting electricity, gas or total energy consumption for industrial furnaces and analyzing energy efficiency.
---

# Predykcja zużycia energii pieca

## Cel
Prognozuj zużycie energii i wykrywaj nadmierne zużycie względem warunków produkcyjnych.

## Target
- `energy_kwh_t_plus_15m`, `energy_kwh_t_plus_60m`, `gas_nm3_t_plus_60m` lub energia na jednostkę produkcji.

## Cechy zalecane
- Temperatury stref i nastawy.
- Masa wsadu, typ receptury, prędkość linii.
- Stan rozgrzewania, produkcji, postoju i wychładzania.
- Otwarcia drzwi i alarmy.
- Temperatura otoczenia, jeśli dostępna.
- Ostatnie zużycie energii i gazu.

## Interpretacja
Rosnący dodatni residual energii przy stabilnej produkcji może oznaczać degradację izolacji, rozregulowanie palników/grzałek, nieszczelność, częste otwarcia drzwi albo problem z regulacją temperatury.

