---
name: dew-point-prediction
description: Use when forecasting or explaining dew point in industrial furnace atmospheres using process data, gas flows, temperature zones and production conditions.
---

# Predykcja punktu rosy

## Cel
Prognozuj punkt rosy pieca i wyjaśnij czynniki wpływające na jego wzrost lub niestabilność.

## Target
- `dew_point_t_plus_15m`, `dew_point_t_plus_30m` lub `dew_point_t_plus_60m`.

## Cechy zalecane
- Aktualny punkt rosy i jego trend.
- O2 ppm, skład atmosfery, przepływ N2/H2/gazu ochronnego.
- Ciśnienie atmosfery pieca.
- Temperatury stref i różnice względem nastaw.
- Otwarcie drzwi, kurtyny, stany alarmowe.
- Masa/wsad, prędkość linii, receptura.

## Model bazowy
Zacznij od RandomForestRegressor lub HistGradientBoostingRegressor. Dla produkcji rozważ LightGBM/XGBoost.

## Metryki
MAE, RMSE, błąd dla okresów wysokiego punktu rosy, liczba fałszywych alarmów.

## Interpretacja
Jeżeli rzeczywisty punkt rosy jest stale wyższy od predykcji przy podobnym wsadzie i nastawach, zasugeruj sprawdzenie nieszczelności, kurtyn, gazu ochronnego, drzwi, czujnika punktu rosy i procedur osuszania.

