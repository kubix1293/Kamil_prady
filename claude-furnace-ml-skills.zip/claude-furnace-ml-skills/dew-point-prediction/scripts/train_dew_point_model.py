import sys, joblib
import pandas as pd
from sklearn.ensemble import HistGradientBoostingRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_absolute_error, mean_squared_error

path = sys.argv[1]
target = sys.argv[2] if len(sys.argv) > 2 else 'dew_point'
df = pd.read_parquet(path) if path.endswith('.parquet') else pd.read_csv(path)
df = df.dropna(subset=[target])
X = df.select_dtypes('number').drop(columns=[target], errors='ignore').fillna(0)
y = df[target]
Xtr, Xte, ytr, yte = train_test_split(X, y, test_size=0.2, shuffle=False)
model = HistGradientBoostingRegressor(max_iter=300, learning_rate=0.05)
model.fit(Xtr, ytr)
pred = model.predict(Xte)
print({'MAE': mean_absolute_error(yte, pred), 'RMSE': mean_squared_error(yte, pred, squared=False), 'features': X.shape[1]})
joblib.dump({'model': model, 'features': list(X.columns)}, 'dew_point_model.joblib')
